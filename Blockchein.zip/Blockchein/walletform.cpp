#include "walletform.h"
#include "ui_walletform.h"

WalletForm::WalletForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::WalletForm)
{
    ui->setupUi(this);
}

WalletForm::~WalletForm()
{
    delete ui;
}

void WalletForm::setValues(WalletStr str)
{
    ui->secretKeyValue_label->setText(str.s_key);
    ui->publicKeyValue_label->setText(str.p_key);
    ui->addressValue_label->setText(str.addr);
    ui->balanceValue_label->setText(QString::number(str.balance));
}
