#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    setWindowTitle("Blockchein");


    ui->setupUi(this);
    QVBoxLayout *lay = new QVBoxLayout;
    tab = new QTabWidget;
    tab->setLayout(lay);
    ui->mainLay->addWidget(tab);

    ui->AddButton->setVisible(false);
    ui->widget_confNoFound->setVisible(false);
    ui->widget_confFounded->setVisible(false);
    ui->startBtn->setVisible(false);

    tab->setVisible(false);


    QFile f("BC.conf");
    if(!f.open(QIODevice::ReadOnly)){
        ui->widget_confNoFound->setVisible(true);
    }else{
        ui->widget_confFounded->setVisible(true);
    }

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::fillForm(int num, WalletStr str)
{
    if(walletsForms.at(num)){
        WalletForm *tmp = walletsForms.at(num);
        tmp->setValues(str);
    }
}


void MainWindow::on_AddButton_clicked()
{
    ui->startBtn->setEnabled(true);
    WalletForm *wallet = new WalletForm();
    walletsForms.append(wallet);
    tab->addTab(wallet,QString::number(walletsForms.size()-1));

    emit generateWallet(walletsForms.size()-1);
}


void MainWindow::on_pushButton_noFoundOK_clicked()
{
    ui->AddButton->setVisible(true);
    ui->startBtn->setVisible(true);
    ui->startBtn->setEnabled(false);
    tab->setVisible(true);
    ui->widget_confNoFound->setVisible(false);
    ui->widget_confFounded->setVisible(false);
    emit newBC();
}

void MainWindow::on_pushButton_createNewBC_clicked()
{
    ui->AddButton->setVisible(true);
    ui->startBtn->setVisible(true);
    ui->startBtn->setEnabled(false);
    tab->setVisible(true);
    ui->widget_confNoFound->setVisible(false);
    ui->widget_confFounded->setVisible(false);
    emit newBC();
}

void MainWindow::on_pushButton_LoadBC_clicked()
{
    emit loadBC();
}

void MainWindow::on_startBtn_clicked()
{
    emit start();
}
