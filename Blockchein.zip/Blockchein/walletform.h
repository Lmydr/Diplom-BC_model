#ifndef WALLETFORM_H
#define WALLETFORM_H

#include <QWidget>
#include "Structs.h"

namespace Ui {
class WalletForm;
}

class WalletForm : public QWidget
{
    Q_OBJECT

public:
    explicit WalletForm(QWidget *parent = nullptr);
    ~WalletForm();

    void init(QByteArrayList data);
    void setValues(WalletStr str);

private:
    Ui::WalletForm *ui;
};

#endif // WALLETFORM_H
